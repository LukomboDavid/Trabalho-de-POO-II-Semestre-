﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public abstract class Docente : Pessoa
    {
        public string Departamento { get; }

        protected Docente(int id, string nome, string departamento) : base(id, nome)
        {
            Departamento = departamento;
        }
    }
    public class Titular : Docente
    {
        public Titular(int id, string nome, string departamento)
            : base(id, nome, departamento) { }
    }
}
