﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public abstract class Avaliacao
    {
        public string Nome { get; }
        public double Nota { get; protected set; }

        protected Avaliacao(string nome, double nota)
        {
            Nome = nome;
            DefinirNota(nota);
        }
        public void DefinirNota(double nota)
        {
            if (nota < 0 || nota > 20) throw new ArgumentOutOfRangeException(nameof(nota), "Nota deve estar entre 0 e 20.");
            Nota = nota;
        }

        public abstract double CalcularNotaFinal();
    }

}
