﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public  class Objecto : Avaliacao
    {
        public double Peso { get; } // ex: 0.30

        public Objecto(double nota, double peso = 0.30) : base("Projecto", nota)
        {
            if (peso <= 0 || peso > 1) throw new ArgumentOutOfRangeException(nameof(peso));
            Peso = peso;
        }

        public override double CalcularNotaFinal() => Nota * Peso;
    }
}
