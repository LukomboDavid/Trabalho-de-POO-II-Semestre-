﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public interface IAvaliavel
    {
        double CalcularNotaFinal();
    }
    public abstract class Pessoa
    {
        public int Id { get; }
        public string Nome { get; }

        protected Pessoa(int id, string nome)
        {
            Id = id;
            Nome = nome;
        }
    }
}
