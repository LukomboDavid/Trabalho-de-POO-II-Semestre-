﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public  class UnidadeCurriculo
    {
        public string Codigo { get; }
        public string Nome { get; }
        public Docente Responsavel { get; }

        private readonly List<Estudante> _inscritos = new();
        public IReadOnlyList<Estudante> Inscritos => _inscritos.AsReadOnly();

        private readonly List<Avaliacao> _avaliacoes = new();
        public IReadOnlyList<Avaliacao> Avaliacoes => _avaliacoes.AsReadOnly();

        private readonly Dictionary<int, List<Avaliacao>> _avaliacoesPorEstudante = new();

        public UnidadeCurriculo(string codigo, string nome, Docente responsavel)
        {
            Codigo = codigo;
            Nome = nome;
            Responsavel = responsavel;
        }

        public void InscreverEstudante(Estudante e)
        {
            if (_inscritos.Any(x => x.Id == e.Id)) return;
            _inscritos.Add(e);
            _avaliacoesPorEstudante[e.Id] = new List<Avaliacao>();
        }

        public void RegistarAvaliacao(Estudante e, Avaliacao avaliacao)
        {
            if (!_avaliacoesPorEstudante.ContainsKey(e.Id))
                throw new InvalidOperationException("Nenhum Estudante encontrado.");

            _avaliacoesPorEstudante[e.Id].Add(avaliacao);
            _avaliacoes.Add(avaliacao);
        }

        public double CalcularNotaFinalDoEstudante(Estudante e)
        {
            if (!_avaliacoesPorEstudante.TryGetValue(e.Id, out var lista))
                throw new InvalidOperationException("Estudante não encontrado.");

            var soma = lista.Sum(a => a.CalcularNotaFinal());
            return Math.Max(0, Math.Min(20, soma));
        }

        public List<ResultadoPauta> ExibirPauta()
        {
            return _inscritos
                .Select(e => new ResultadoPauta(e, CalcularNotaFinalDoEstudante(e)))
                .OrderByDescending(r => r.NotaFinal)
                .ThenBy(r => r.Estudante.Nome)
                .ToList();
        }
        

        public string EmitirPautaEmTexto()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Pauta - {Codigo} {Nome}");
            sb.AppendLine($"Responsável: {Responsavel.Nome} ({Responsavel.GetType().Name})");
            sb.AppendLine(new string('-', 45));

            foreach (var r in ExibirPauta())
                sb.AppendLine(r.ToString());

            return sb.ToString();
        }
    }
}

