﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public  class Teste : Avaliacao
    {
        public double Peso { get; } // ex: 0.30

        public Teste(double nota, double peso = 0.30) : base("Teste", nota)
        {
            if (peso <= 0 || peso > 1) throw new ArgumentOutOfRangeException(nameof(peso));
            Peso = peso;
        }

        public override double CalcularNotaFinal() => Nota * Peso;
    }
}
