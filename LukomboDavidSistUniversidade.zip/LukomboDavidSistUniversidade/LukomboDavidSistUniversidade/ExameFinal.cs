﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public  class ExameFinal : Avaliacao
    {
        public double Peso { get; } // ex: 0.40

        public ExameFinal(double nota, double peso = 0.40) : base("Exame Final", nota)
        {
            if (peso <= 0 || peso > 1) throw new ArgumentOutOfRangeException(nameof(peso));
            Peso = peso;
        }

        public override double CalcularNotaFinal() => Nota * Peso;
    }
}
