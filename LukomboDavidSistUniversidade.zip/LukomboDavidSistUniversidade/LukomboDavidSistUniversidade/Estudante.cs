﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public  class Estudante : Pessoa
    {
        public string Numero { get; }
        
        

        public Estudante(int  id, string nome, string numero) : base(id, nome)
        {
            
            Numero = numero;

        }
    }
}
