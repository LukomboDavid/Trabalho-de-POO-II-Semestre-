﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public abstract class Assistente : Docente
    {
        public Assistente(int id, string nome, string departamento)
            : base(id, nome, departamento) { }
    }
}
