﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LukomboDavidSistUniversidade
{
    public class ResultadoPauta 
    {
        public Estudante Estudante { get; }
        public double NotaFinal { get; }

        public ResultadoPauta(Estudante estudante, double notaFinal)
        {
            Estudante = estudante;
            NotaFinal = notaFinal;
        }

        public override string ToString()
            => $"{Estudante.Numero} - {Estudante.Nome} : {NotaFinal:0.00}";
    }
}
