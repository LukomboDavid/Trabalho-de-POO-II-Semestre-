﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Markup;

namespace ConsoleApp1
{
    public class Veiculo
    {
        private string matricula;
        private string marca;
        private string modelo;
        private int anoFabricação;
        private double quilomentragem;

        public Veiculo() { }

        public Veiculo(string matricula, string marca, string modelo, int anoFabricação, double quilomentragem)
        {
            this.matricula = matricula;
            this.marca = marca;
            this.modelo = modelo;
            this.anoFabricação = anoFabricação;
            this.quilomentragem = quilomentragem;
        }

        public string Matricula { get { return matricula; }
                                  set { matricula = value; } }
            public string Marca { get { return marca; } 
                                  set { marca = value; } }
        public string Modelo { get { return modelo; } 
                               set { modelo = value; } }
        public int AnoFabrica { get { return anoFabricação; } set { anoFabricação = value; } }
        public double Quilomentragem { get { return quilomentragem; } set { quilomentragem = value; } }

        public void ActualizarQuilometragem(double km)
        {
            quilomentragem += km;
        }

        public void ApresentarDados()
        {
            Console.WriteLine($"Matricula: {matricula}");
            Console.WriteLine($"Marca: {marca}");
            Console.WriteLine($"Modelo: {modelo}");
            Console.WriteLine($"AnoFabrica: {anoFabricação}");
            Console.WriteLine($"Quilometragem:{quilomentragem} Km");

            Console.WriteLine("------------------------------------");
        }


    }
}
