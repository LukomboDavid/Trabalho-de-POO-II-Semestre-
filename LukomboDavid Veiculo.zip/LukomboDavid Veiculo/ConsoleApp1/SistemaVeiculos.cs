﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class SistemaVeiculos
    {
        private List<Veiculo> listaVeiculos = new List<Veiculo>();

        public void RegistarVeiculo(Veiculo v)
        {
            listaVeiculos.Add(v);
        }

        public void ActualizarQuilometragem(string matricula, double Km)
        {
            foreach (var veiculo in listaVeiculos)
            {
                if (veiculo.Matricula == matricula)
                {
                    veiculo.ActualizarQuilometragem(Km);

                    Console.WriteLine("Quilometragem actualizada com sucesso!");
                    return;

                }
            }
            Console.WriteLine("Veiculo não encontrado!");
        }

        public void ApresentarVeiculo(string matricula)
        {
            foreach (var v in listaVeiculos)
            {
                if (v.Matricula == matricula)
                {
                    v.ApresentarDados();
                    return;
                }
            }
            Console.WriteLine("Veículo não encontrado!");

            Console.ReadLine();
        }
    }


}
