﻿using ConsoleApp1;

public class Program
{
    static void Main()
    {
        SistemaVeiculos sistema = new SistemaVeiculos();

        sistema.RegistarVeiculo(new Veiculo("LD-234-AA", "Toyota", "Corolla", 1985, 3780000));

        sistema.RegistarVeiculo(new Veiculo("LD-25-57", "Hyundai", "i10", 2023, 4500000));
        sistema.RegistarVeiculo(new Veiculo("LD-23-CC", "Toyota", "Hilux", 2020, 39000000));


        sistema.ActualizarQuilometragem("LD-234-AA", 20000);
        sistema.ActualizarQuilometragem("LD-25-57-CN", 3000);


        sistema.ApresentarVeiculo("LD-234-AA");

        sistema.ApresentarVeiculo("LD-25-57");

        sistema.ApresentarVeiculo("LD-23-CC");




    }
}
